from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql+psycopg2://postgres:1234@localhost:5432/postgres"
app.config['SECRET_KEY'] = 'liba'
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    password_hash = db.Column(db.String, nullable=False)
    email = db.Column(db.String, unique=True, nullable=False)
    role = db.Column(db.String, nullable=False)

    def get_id(self):
        return str(self.user_id)

class Book(db.Model):
    __tablename__ = 'books'
    book_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String, nullable=False)
    author = db.Column(db.String, nullable=False)
    genre = db.Column(db.String, nullable=False)
    available_copies = db.Column(db.Integer, nullable=False)
    total_copies = db.Column(db.Integer, nullable=False)

class Rental(db.Model):
    __tablename__ = 'rentals'
    rental_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('books.book_id'), nullable=False)
    rental_date = db.Column(db.Date, default=datetime.utcnow, nullable=False)
    return_date = db.Column(db.Date, nullable=True)

    user = db.relationship("User", back_populates="rentals")
    book = db.relationship("Book", back_populates="rentals")

User.rentals = db.relationship("Rental", order_by=Rental.rental_id, back_populates="user")
Book.rentals = db.relationship("Rental", order_by=Rental.rental_id, back_populates="book")


def checkUser(username, email):
    if User.query.filter_by(username=username).first():
        return True
    if User.query.filter_by(email=email).first():
        return True

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()

@app.route('/')
def hello_page():
    return render_template('hello_page.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        role = request.form['role']
        if checkUser(username, email):
            return redirect(url_for('register'))
        hashed_password = generate_password_hash(password, 'pbkdf2:sha256')
        new_user = User(username=username, password_hash=hashed_password, email=email, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful!', 'success')
        user = User.query.filter_by(username=username).first()
        login_user(user)
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login unsuccessful. Check username and/or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        books = Book.query.all()
        rentals = Rental.query.filter_by(return_date=None).all()
        return render_template('admin_dashboard.html', books=books, rentals=rentals)
    else:
        available_books = Book.query.filter(Book.available_copies > 0).all()
        return render_template('reader_dashboard.html', books=available_books)


@app.route('/add_book', methods=['GET', 'POST'])
@login_required
def add_book():
    if current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        genre = request.form['genre']
        total_copies = request.form['total_copies']
        new_book = Book(title=title, author=author, genre=genre, available_copies=total_copies, total_copies=total_copies)
        db.session.add(new_book)
        db.session.commit()
        flash('Book added successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('add_book.html')

@app.route('/rent_book/<int:book_id>', methods=['POST'])
@login_required
def rent_book(book_id):
    if current_user.role == 'admin':
        flash('Admins cannot rent books.', 'danger')
        return redirect(url_for('dashboard'))
    book = Book.query.get_or_404(book_id)
    if book.available_copies > 0:
        book.available_copies -= 1
        new_rental = Rental(user_id=current_user.user_id, book_id=book.book_id, rental_date=datetime.utcnow())
        db.session.add(new_rental)
        db.session.commit()
        flash('Book rented successfully!', 'success')
    else:
        flash('No available copies of this book.', 'danger')
    return redirect(url_for('dashboard'))

@app.route('/return_book/<int:rental_id>', methods=['POST'])
@login_required
def return_book(rental_id):
    rental = Rental.query.get_or_404(rental_id)
    if rental.user_id != current_user.user_id:
        flash('You do not have permission to return this book.', 'danger')
        return redirect(url_for('dashboard'))
    if rental.return_date:
        flash('This book has already been returned.', 'danger')
        return redirect(url_for('dashboard'))

    book = Book.query.get_or_404(rental.book_id)
    book.available_copies += 1
    rental.return_date = datetime.utcnow()
    db.session.commit()
    flash('Book returned successfully!', 'success')
    return redirect(url_for('dashboard'))



if __name__ == '__main__':
    app.run(debug=True)
